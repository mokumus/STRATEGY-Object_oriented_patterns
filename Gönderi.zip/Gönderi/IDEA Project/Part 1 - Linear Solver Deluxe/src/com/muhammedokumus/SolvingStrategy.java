package com.muhammedokumus;

interface SolvingStrategy {
    float[] solveLinearEquations(float[][] augmentedMatrix);
}
