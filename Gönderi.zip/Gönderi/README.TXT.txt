How to run the executable in command line or terminal:

$ java -jar LSD.jar

-Requires java 8 or above
